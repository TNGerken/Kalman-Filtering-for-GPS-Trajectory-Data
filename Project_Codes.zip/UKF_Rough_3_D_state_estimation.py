###Need dimension update
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import time

def read_geolife_plt(filepath):
    df = pd.read_csv(filepath, skiprows=6, header=None)
    df.columns = ['latitude', 'longitude', 'zeros', 'altitude', 'date', 'time1','time2']
    return df
def f_func(x_state,dt): 
    return np.array([[x_state[0]+dt*x_state[1]+(0.5)*dt*x_state[2]],[x_state[1]+x_state[2]*dt],[x_state[2]]])

file_path = r"SDE/Project/Geolife Trajectories 1.3/Data/000/Trajectory/20090403011657.plt"

df = read_geolife_plt(file_path)
df['datetime'] = pd.to_datetime("1899-12-30") + pd.to_timedelta(df['date'], unit="D")
dt = df['datetime'].diff().dt.total_seconds().fillna(1).to_numpy()
dt = np.clip(dt,1e-2,10) 

altitude = df['altitude'].to_numpy()
time2 = df['datetime'].to_numpy()
x=np.array(altitude)
k =np.arange(1,len(time2))
H=np.array([[1,0,0],[0,1,0]])

x_hat = np.zeros((2,2,len(k)))


P = np.zeros((3,3,len(k)))
P_ = np.zeros((3,3,len(k)),dtype=float)
x_hat = np.zeros((3,len(k)))
x_hat_a=np.zeros((5,1,len(k)))
x_hat_ = np.zeros((3,len(k)))
alpha_1 = 1
alpha_2 = 0.5
alpha_3=0.2


R_v = alpha_1
scale=10
scale_2=10
R_n = alpha_2 
scale_2=10
R_x=alpha_3
v = np.random.normal(0,np.sqrt(R_v),size=len(k))
n = np.random.normal(0,np.sqrt(R_n), size=len(k))
dx = np.diff(x)
dv = np.diff(dx)
v = dx/dt[0:-1]
a = dv/dt[0:-2]

x_state = np.zeros((2,len(k)))
x_state[0,:] = x[0:-1]
x_state[1,:] = v

#Initialize
x_hat[0,0]=x[0]
x_hat[1,0]=np.mean(v[:5])
x_hat[2,0]=np.mean(a[:5])
P[:,:,0]=np.diag([1,10,20])

x_hat_a[0,0,0] =x_hat[0,0]
x_hat_a[1,0,0] =x_hat[1,0]
x_hat_a[2,0,0] =x_hat[2,0]

P_a = np.zeros((5,5,len(k)))
P_a[0:3,0:3,0] = P[:,:,0] 
P_a[3,3,0] = R_v 
P_a[4,4,0] = R_n

n = 4
aa = 1e-2
lam = aa**2*n-n
beta =2
gamma = (5+lam)**(0.5)

Wm = np.zeros((1, 11))
Wc = np.zeros((1,11))
Wm[0,0] = lam/(4+lam)
Wc[0,0] = lam/(4+lam)+(1-aa**2+beta)
Wm[0,1:] = 1/(2*(4+lam))
Wc[0,1:] = 1/(2*(4+lam))
X_a=np.zeros((5,11,len(k)))
X_x_pred = np.zeros((3,11,len(k)))

##Measurement space variables
Y = np.zeros((2,11,len(k)))
y_hat = np.zeros((2,len(k)))
P_y_y = np.zeros((2,2,len(k)))
P_x_y = np.zeros((3,2,len(k)))
K_k = np.zeros((3,2,len(k)))
innovation =np.zeros((2,len(k)))

ts_l_1=time.time()

for i in range(1,len(k)): 
    #Eqn.7.39
    sqrt_Pa = np.linalg.cholesky(P_a[:,:,i-1] + 1e-6*np.eye(5))  # shape (4,4)
    X_a[:,0,i] = x_hat_a[:,0,i-1]
    for j in range(n):
        X_a[:,1+j,i]=x_hat_a[:,0,i-1]+gamma*sqrt_Pa[:,j]
        X_a[:,1+n+j,i]=x_hat_a[:,0,i-1]-gamma*sqrt_Pa[:,j]

    X_x=X_a[0:3,:,i]
    X_v=X_a[3,:,i]
    X_n=X_a[4,:,i]

    #Eqn 7.40
    for j in range(11): 
        aux1 = X_x[:,j]
        X_x_pred[0,j,i]=f_func(aux1,dt[i])[0]
        X_x_pred[1,j,i]=f_func(aux1,dt[i])[1]
        X_x_pred[2,j,i]=f_func(aux1,dt[i])[2]
 
    #Eqn. 7.41
    for j in range(11):
        x_hat_[:,[i]]+=Wm[0,j]*X_x_pred[:,[j],[i]]

    #7.42
    for j in range(11):
        P_[:,:,i]+=Wc[0,j]*(X_x_pred[:,[j],[i]]-x_hat_[:,[i]])*((X_x_pred[:,[j],[i]]-x_hat_[:,[i]]).T)
    
    Q = np.diag([2,1,1])
    P_[:,:,i] += Q
    #7.43
    
    for j in range(11):
        Y[:,j,i] = H@X_x_pred[:,j,i]

    #7.44
    for j in range(11):
        y_hat[:,[i]] += Wm[0,j]*Y[:,j,[i]] 
    
    #7.45
    for j in range(11): 
        P_y_y[:,:,i] +=Wc[0,j]*(Y[:,j,[i]]-y_hat[:,[i]])*((Y[:,j,[i]]-y_hat[:,[i]]).T)
    P_y_y[:,:,i] += 1e-3*np.eye(2) #Regularization term in case of singular matrix 

    #7.46
    for j in range(11): 
        P_x_y[:,:,i] += Wc[0,j]*(X_x_pred[:,[j],[i]]-x_hat_[:,[i]])@((Y[:,j,[i]]-y_hat[:,[i]]).T)

    #7.47
    K_k[:,:,i] = P_x_y[:,:,i]@np.linalg.inv(P_y_y[:,:,i])

    #7.48
    z_i = np.array([[x[i]], [v[i]]])

    x_hat[:, [i]] = x_hat_[:, [i]] + K_k[:, :, i] @ (z_i - y_hat[:, [i]])
    innovation[:, i] = (z_i - y_hat[:, [i]]).flatten()

    #7.49
    I = np.eye(3)
    R = np.diag([R_v,R_n])
    P[:,:,i]=(I-K_k[:,:,i]@H)@P_[:,:,i]@(I-K_k[:,:,i]@H).T+K_k[:,:,i]@R@K_k[:,:,i].T

    x_hat_a[0,0,i]=x_hat[0,i]
    x_hat_a[1,0,i]=x_hat[1,i]
    x_hat_a[2,0,i]=x_hat[2,i]

G = np.zeros((3,3,len(k)))
x_hat_s = np.zeros((3,len(k)))
P_s= np.zeros_like(P)
P_s[:,:,-1] = P[:,:,-1]

# Initialize last state (they match filtered at final time)
x_hat_s[:,-1]=x_hat[:,-1]
P_s[:,:,-1]=P[:,:,-1]

# Run smoother backwards
for i in range(len(k)-2,-1,-1): 
    epsilon=1
    G[:,:,i]=P[:,:,i]@np.linalg.inv(P_[:,:,i+1]+epsilon*np.eye(3))
    x_hat_s[:,i]=x_hat[:,i]+G[:,:,i]@(x_hat_s[:,i+1]-x_hat_[:,i+1])
    P_s[:,:,i] = P[:,:,i]+G[:,:,i]@(P_s[:,:,i+1]-P_[:,:,i+1])@G[:,:,i].T

ts_l_2 = time.time()
print(f"Time:{ts_l_2-ts_l_1}")

avg_altitude_innovation=np.sqrt(np.mean((innovation[0,:])**2))
avg_velocity_innovation=np.sqrt(np.mean((innovation[1,:])**2))
mean_1 =np.mean((innovation[0,:])**2)
mean_2 =np.mean((innovation[1,:])**2)
avg_total_innovation=np.sqrt(mean_1 +mean_2)

print(f"Innovation RMS")
print(f"Altitude: {avg_altitude_innovation}")
print(f"Velocity: {avg_velocity_innovation}")
print(f"Total: {avg_total_innovation}")
 
avg_altitude_uncertainty = np.mean(np.sqrt(P[0,0,:],))
avg_velocity_uncertainty=np.mean(np.sqrt(P[1,1,:]))
avg_acc_uncertainty=np.mean(np.sqrt(P[2,2,:]))
print(f"Average Uncertainty")
print(f"Altitude: {avg_altitude_uncertainty}")
print(f"Velocity: {avg_velocity_uncertainty}")
print(f"Velocity: {avg_acc_uncertainty}")

fig,ax =plt.subplots(3,1,figsize=(6,8))
ax[0].plot(k,x[0:len(k)],label='Observation')
ax[0].plot(k,x_hat[0,:],label='Estimate')
#ax[0].plot(k,x_hat_s[0,:],label='Smooth')
ax[0].set_ylabel("Altitude")
plt.suptitle(fr"UKF State Estimation (3-D)",y=0.99)
ax[1].plot(k,v[0:len(k)],label='Observation')
ax[1].plot(k,x_hat[1,:],label='Estimate')
#ax[1].plot(k,x_hat_s[1,:],label='Smooth')
ax[1].set_ylabel("Velocity")
ax[2].plot(k[0:len(a)],a,label='Observation')
ax[2].plot(k,x_hat[2,:],label='Estimate')
#ax[2].plot(k,x_hat_s[2,:],label='Smooth')
ax[2].set_ylabel("Acceleration")
for a in range(3): 
    ax[a].set_xlabel("Time")
    ax[a].grid(True)
    ax[a].legend()
plt.tight_layout()

fig,ax =plt.subplots(2,1,figsize=(6,8))
plt.suptitle(f"UKF State Estimation Errors (3-D)",y=0.99)
ax[0].plot(k,innovation[0,:],label='Altitude')
ax[0].plot(k,innovation[1,:],label='Velocity')
ax[0].set_ylabel("Innovation")
ax[1].plot(k,P[0,0,:],label='Altitude')
ax[1].plot(k,P[1,1,:],label='Velocity')
ax[1].plot(k,P[2,2,:],label='Acceleration')
ax[1].set_ylabel("Uncertainty")
for a in range(2): 
    ax[a].set_xlabel("Time")
    ax[a].grid(True)
    ax[a].legend()
plt.tight_layout()

plt.show()