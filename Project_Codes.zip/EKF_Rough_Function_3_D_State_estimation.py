import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import time

def read_geolife_plt(filepath):
    df = pd.read_csv(filepath, skiprows=6, header=None)
    df.columns = ['latitude', 'longitude', 'zeros', 'altitude', 'date', 'time1','time2']
    return df
def f_func(x,v,a, dt): 
    return np.array([[x+dt*v+0.5*a*(dt**2)],[v+a*dt],[a]])
def jac(dt): 
    return np.array([[1,dt,0.5*dt**2],[0,1,dt],[0,0,1]])

file_path = r"SDE/Project/Geolife Trajectories 1.3/Data/000/Trajectory/20090403011657.plt"

df = read_geolife_plt(file_path)
df['datetime'] = pd.to_datetime("1899-12-30") + pd.to_timedelta(df['date'], unit="D")
dt = df['datetime'].diff().dt.total_seconds().fillna(1).to_numpy()
altitude = df['altitude'].to_numpy()
time2 = df['datetime'].to_numpy()
dt = np.clip(dt, 1e-2, 10) 

x=np.array(altitude)
k =np.arange(1,len(time2))

H=np.array([[1,0,0],[0,1,0]])

P = np.zeros((3,3,len(k)))
P_ = np.zeros((3,3,len(k)),dtype=float)
x_hat = np.zeros((3,len(k)))
x_hat_=np.zeros((3,len(k)))
alpha=10
G=np.zeros((3,2,len(k))) 
Q=np.zeros((3,3,len(k)))
R=np.eye(2)*alpha 
v=np.diff(x)/dt[1:]  
a=np.diff(v)/dt[2:]  
v=np.pad(v,(1,0),mode='edge')
a=np.pad(a,(2,0),mode='edge')


x_hat_[0,0]=np.mean(x[:5])
x_hat_[1,0]= np.mean(v[:5])
x_hat_[2,0]=np.mean(a[:5])
x_hat[:,0] = x_hat_[:,0]  

P[:,:,0]=np.array([[1,10,10],[10,10,10],[10,10,20]])
scale_x = 1
scale_y = 1
scale_z=1
 
s2_x=max(1e-2,np.var(np.diff(x))) 
s2_v=max(1e-2,np.var(np.diff(v)))
s2_a=max(1e-2,np.var(np.diff(a)))
x_state=np.zeros((3,len(k)))
x_state = np.vstack([x, v, a])
innovation =np.zeros((2,len(k)))
R = np.diag([np.var(x[:100]),np.var(v[:100])]) * alpha
ts_l_1=time.time()
for i in range(1,len(k)-1): 
    F=jac(dt[i])
    x_hat_[:,i]=f_func(*x_hat[:,i-1],dt[i]).flatten()
    Q[:,:,i-1]=np.diag([s2_x,s2_v,s2_a])*dt[i]*1e-4

    P_[:,:,i]=F@P[:,:,i-1]@F.T+Q[:,:,i-1]

    aux_a =H@P_[:,:,i]@H.T+R


    G[:,:,i]=P_[:,:,i]@H.T@(np.linalg.inv(aux_a))
    
    innovation[:,[i]] =x_state[0:2,[i]]-H@x_hat_[:,[i]]
    aux=x_hat_[:,[i]]+G[:,:,i]@innovation[:,[i]]

    x_hat[0,i]=aux[0]
    x_hat[1,i]=aux[1]
    x_hat[2,i]=aux[2]
    P[:,:,i]=(np.eye(3)-G[:,:,i]@H)@P_[:,:,i]
    
ts_l_2 = time.time()
print(f"Time:{ts_l_2-ts_l_1}")

avg_altitude_innovation=np.sqrt(np.mean((innovation[0,:])**2))
avg_velocity_innovation=np.sqrt(np.mean((innovation[1,:])**2))
mean_1 =np.mean((innovation[0,:])**2)
mean_2 =np.mean((innovation[1,:])**2)
avg_total_innovation=np.sqrt(mean_1 +mean_2)

print(f"Innovation RMS")
print(f"Altitude: {avg_altitude_innovation}")
print(f"Velocity: {avg_velocity_innovation}")
print(f"Total: {avg_total_innovation}")

avg_altitude_uncertainty = np.mean(np.sqrt(P[0,0,:],))
avg_velocity_uncertainty=np.mean(np.sqrt(P[1,1,:]))
avg_acc_uncertainty=np.mean(np.sqrt(P[2,2,:]))
print(f"Average Uncertainty")
print(f"Altitude: {avg_altitude_uncertainty}")
print(f"Velocity: {avg_velocity_uncertainty}")
print(f"Velocity: {avg_acc_uncertainty}")

fig,ax =plt.subplots(3,1,figsize=(6,8))
ax[0].plot(k,x[0:len(k)],label='Observation')
ax[0].plot(k,x_hat[0,:],label='Estimate')
ax[0].set_ylabel("Altitude")
plt.suptitle(fr"EKF State Estimation (3-D)",y=0.99)
ax[1].plot(k,v[0:len(k)],label='Observation')
ax[1].plot(k,x_hat[1,:],label='Estimate')
ax[1].set_ylabel("Velocity")
ax[2].plot(k,a[0:len(k)],label='Observation')
ax[2].plot(k,x_hat[2,:],label='Estimate')
ax[2].set_ylabel("Acceleration")
for a in range(3): 
    ax[a].set_xlabel("Time")
    ax[a].grid(True)
    ax[a].legend()
plt.tight_layout()

fig,ax =plt.subplots(2,1,figsize=(6,8))
plt.suptitle(f"EKF State Estimation Errors (3-D)",y=0.99)
ax[0].plot(k,innovation[0,:],label='Altitude')
ax[0].plot(k,innovation[1,:],label='Velocity')
ax[0].set_ylabel("Innovation")
ax[1].plot(k,P[0,0,:],label='Altitude')
ax[1].plot(k,P[1,1,:],label='Velocity')
ax[1].plot(k,P[2,2,:],label='Acceleration')
ax[1].set_ylabel("Uncertainty")
for a in range(2): 
    ax[a].set_xlabel("Time")
    ax[a].grid(True)
    ax[a].legend()
plt.tight_layout()

plt.show()