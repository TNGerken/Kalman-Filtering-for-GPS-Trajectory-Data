#2-D State Estimation (Smooth)
#Kalman Filter

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import time

def read_geolife_plt(filepath):
    df = pd.read_csv(filepath, skiprows=6, header=None)
    df.columns = ['latitude', 'longitude', 'zeros', 'altitude', 'date', 'time1','time2']
    return df
def f_func(x,v,dt): 
    return np.array([[x+dt*v],[v]])
 
#file_path = r"SDE/Project/Geolife Trajectories 1.3/Data/000/Trajectory/20090403011657.plt"
file_path = r"SDE/Project/Geolife Trajectories 1.3/Data/000/Trajectory/20090628005229.plt"

df = read_geolife_plt(file_path)
df['datetime'] = pd.to_datetime("1899-12-30") + pd.to_timedelta(df['date'], unit="D")
dt = df['datetime'].diff().dt.total_seconds().fillna(1).to_numpy()
dt = np.clip(dt, 1e-2, 10) 

altitude = df['altitude'].to_numpy()
time2 = df['datetime'].to_numpy()

x=np.array(altitude)
k =np.arange(1,len(time2))
H=np.array([[1,0]]) 

P = np.zeros((2,2,len(k))) 
P_ = np.zeros((2,2,len(k)),dtype=float)
x_hat = np.zeros((2,len(k)))
x_hat_=np.zeros((2,len(k)))
alpha=30
G = np.zeros((2,1,len(k))) 
Q = np.zeros((2,2,len(k)))

v = np.diff(x) / dt[1:]  
v = np.pad(v, (1, 0), mode='edge')

x_hat_[0,0]=np.mean(x[:5])
x_hat_[1,0]= np.mean(v[:5])

x_hat[:,0] = x_hat_[:,0] 
P[:,:,0]=np.diag([1,10])
s2_x=max(1e-2,np.var(np.diff(x))) 
s2_v=max(1e-2,np.var(np.diff(v)))
x_state=np.zeros((2,len(k)))
x_state = np.vstack([x, v])
R = np.diag([np.var(x[:100])]) * alpha
innovation =np.zeros((1,len(k)))

ts_l_1=time.time()
 
for i in range(1,len(k)): 
    F = np.array([[1, dt[i]], [0, 1]])
    x_hat_[:,i]= (F@x_hat[:, i-1])
    Q[:,:,i-1]=np.array([[s2_x*dt[i], s2_x*dt[i]/2],
                     [s2_x*dt[i]/2, s2_v*dt[i]]])*(1e-3)

    P_[:,:,i]=F@P[:,:,i-1]@F.T+Q[:,:,i-1]


    aux_a =H@P_[:,:,i]@H.T+R

    G[:,:,i]=P_[:,:,i]@H.T@(np.linalg.inv(aux_a))

    innovation[:, i] = x[i] - H @ x_hat_[:, i]
    aux=x_hat_[:,[i]]+G[:,:,i]@innovation[:,[i]]
    x_hat[0,i]=aux[0]
    x_hat[1,i]=aux[1]
    P[:,:,i]=(np.eye(2)-G[:,:,i]@H)@P_[:,:,i]
ts_l_2 = time.time()
print(f"Time:{ts_l_2-ts_l_1}")

avg_altitude_innovation=np.sqrt(np.mean((innovation[0,:])**2))

print(f"Innovation RMS")
print(f"Altitude: {avg_altitude_innovation}")

avg_altitude_uncertainty = np.mean(np.sqrt(P[0,0,:],))
avg_velocity_uncertainty=np.mean(np.sqrt(P[1,1,:]))

print(f"Average Uncertainty")
print(f"Altitude: {avg_altitude_uncertainty}")
print(f"Velocity: {avg_velocity_uncertainty}")

fig,ax =plt.subplots(2,1,figsize=(6,8))
ax[0].plot(k,x[0:len(k)],label='Observation')
ax[0].plot(k,x_hat[0,:],label='Estimate')
ax[0].set_ylabel("Altitude")
plt.suptitle(fr"KF State Estimation (2-D)",y=0.99)
ax[1].plot(k,v[0:len(k)],label='Observation')
ax[1].plot(k,x_hat[1,:],label='Estimate')
ax[1].set_ylabel("Velocity")
for a in range(2): 
    ax[a].set_xlabel("Time")
    ax[a].grid(True)
    ax[a].legend()
plt.tight_layout()

fig,ax =plt.subplots(2,1,figsize=(6,8))
plt.suptitle(f"KF State Estimation Errors (2-D)",y=0.99)
ax[0].plot(k,innovation[0,:],label='Altitude')
ax[0].set_ylabel("Innovation")
ax[1].plot(k,P[0,0,:],label='Altitude')
ax[1].plot(k,P[1,1,:],label='Velocity')
ax[1].set_ylabel("Uncertainty")
for a in range(2): 
    ax[a].set_xlabel("Time")
    ax[a].grid(True)
    ax[a].legend()
plt.tight_layout()

plt.show()

