import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def read_geolife_plt(filepath):
    df = pd.read_csv(filepath, skiprows=6, header=None)
    df.columns = ['latitude', 'longitude', 'zeros', 'altitude', 'date', 'time1','time2']
    return df

file_path = r"SDE/Project/Geolife Trajectories 1.3/Data/000/Trajectory/20090403011657.plt"
df = read_geolife_plt(file_path)
altitude=df['altitude']
lat=df['latitude']
long=df['longitude']
time =df['date']
time = np.array(time)
x=np.array(altitude)
lat=np.array(lat)
long=np.array(long)
print(len(time))
n =np.arange(0,len(time))

vh=np.diff(x)/np.diff(time)
ah=np.diff(vh)/np.diff(time[0:-1])
dt = np.diff(time)
fig,ax=plt.subplots(3,1,figsize=(6,8))
plt.suptitle(f"File: {file_path[-18:-4]}",y=0.99)
ax[0].plot(time,altitude,label='Altitude')
ax[0].set_ylabel("Altitude")
ax[1].plot(time,lat,label='Latitude')
ax[1].set_ylabel("Latitude")
ax[2].plot(time,long,label='Longitude')
ax[2].set_ylabel("Longitude")
for a in range(3): 
    ax[a].set_xlabel("Time")
    ax[a].grid(True)
    ax[a].legend()
plt.tight_layout()

fig,ax =plt.subplots(4,1,figsize=(6,8))
plt.suptitle(f"File: {file_path[-18:-4]}",y=0.99)
ax[0].plot(time,altitude,label='Altitude')
ax[0].set_ylabel("Altitude")
ax[1].plot(time[0:-1],vh,label='Velocity')
ax[1].set_ylabel("Velocity")
ax[2].plot(time[0:-2],ah,label='Acceleration')
ax[2].set_ylabel("Acceleration")
ax[3].plot(time[0:-1],dt,label='$\Delta$t')
ax[3].set_ylabel("$\Delta$t")
for a in range(4): 
    ax[a].set_xlabel("Time")
    ax[a].grid(True)
    ax[a].legend()
plt.tight_layout()
plt.show()


